#ifndef __SYSTICK_H__
#define __SYSTICK_H__

#include "chip.h"

void systick_init(uint32_t hz);

#endif

/******************************* (C) COPYRIGHT 2015 GAKATO ******************************/
/****************************************END OF FILE*************************************/


