#ifndef __BOARD_WDT_H__
#define __BOARD_WDT_H__

void board_wdt_init(void);    // ���Ź���ʼ��
void board_wdt_feed(void);    // ι��

#endif

/******************************* (C) COPYRIGHT 2015 GAKATO ******************************/
/****************************************END OF FILE*************************************/


