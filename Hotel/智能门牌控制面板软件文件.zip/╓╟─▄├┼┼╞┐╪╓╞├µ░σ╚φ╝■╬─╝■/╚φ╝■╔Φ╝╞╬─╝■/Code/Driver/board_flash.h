
void FlashWriteData(void *buf,unsigned long addr,unsigned char len);
void FlashReadData(unsigned char *buf,unsigned long addr,unsigned int len);
void FlashErase(unsigned long addr);

/******************************* (C) COPYRIGHT 2015 GAKATO ******************************/
/****************************************END OF FILE*************************************/


